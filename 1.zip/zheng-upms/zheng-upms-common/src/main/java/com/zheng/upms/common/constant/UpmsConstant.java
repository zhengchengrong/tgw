package com.zheng.upms.common.constant;

import com.zheng.common.base.BaseConstants;

/**
 * upms系统常量类
 * Created by shuzheng on 2017/2/18.
 */
public class UpmsConstant extends BaseConstants {

    public static final String UPMS_TYPE = "zheng.upms.type";

}
